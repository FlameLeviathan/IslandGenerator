package com.chivalrycraft.islandgenerator;




import org.bukkit.*;

import org.bukkit.generator.ChunkGenerator;
import org.bukkit.util.noise.SimplexOctaveGenerator;


import java.util.Random;

public class CustomChunkGenerator extends ChunkGenerator {
    Core core;
    int currentHeight = 50;

    public CustomChunkGenerator(Core core){
        this.core = core;
    }

    @Override
    public org.bukkit.generator.ChunkGenerator.ChunkData generateChunkData(World world, Random random, int chunkX, int chunkZ, org.bukkit.generator.ChunkGenerator.BiomeGrid biome) {
        // TODO Chunk generation code here.
        org.bukkit.generator.ChunkGenerator.ChunkData chunk = createChunkData(world);
        //(Math.random() * ((max - min) + 1)) + min

        //Create random numbers for generation
        double randomHeight = 65;//(Math.random() * ((200 - 50) + 1)) + 50;
        int randomRadius = 15;//(int)(Math.random() * ((40 - 10) + 1)) + 10;
        int randomSize = 1;//(int)(Math.random() * ((15 - 1) + 1)) + 1;
        int randomNum = (int)(Math.random() * ((4 - 1) + 1)) + 1;

/*        for (int X = 0; X < 16; X++)
            for (int Z = 0; Z < 16; Z++) {
                currentHeight = (int) (generator.noise(chunkX*16+X, chunkZ*16+Z, 0.5D, 0.5D)*15D+50D);
                //chunk.setBlock(X, currentHeight, Z, Material.AIR);
                chunk.setBlock(X, currentHeight-1, Z, Material.DIRT);
                for (int i = currentHeight-2; i > 0; i--)
                    chunk.setBlock(X, i, Z, Material.STONE);
                chunk.setBlock(X, 0, Z, Material.BEDROCK);
            }*/
        //Generate island in chunk?
        //if (!core.chunkBlocks.isEmpty() && core.chunkBlocks.containsKey(chunk)){
            //Bukkit.getLogger().info("Passes 1");
            //placeBlocksInChunk(chunk, chunkX, chunkZ);
        //} else {
            //Bukkit.getLogger().info("Passes 2");
            if (randomNum > 3) {
                //Bukkit.getLogger().info("Passes 3");
                IslandType type = new IslandType(randomRadius, IslandType.Biome.PLAIN);
                Island island = new Island(type, new Location(world, (double) chunkX, randomHeight, (double) chunkZ), chunk, core);
                //Bukkit.getLogger().info("Coordinates: " + (double)chunkX + ", " + randomHeight + ", " + (double)chunkZ);
                //Bukkit.getLogger().info("Passes 4");
                island.makeIsland(randomSize);
               // Bukkit.getLogger().info("Passes 5");
                //placeBlocksInChunk(chunk, chunkX, chunkZ);
            }
        //}


        //Bukkit.getLogger().info("Chunk created!");
        return chunk;
    }


    void placeBlocksInChunk(ChunkGenerator.ChunkData data, int chunkX, int chunkZ){
        for (Location chunk: core.chunkBlocks.keySet()) {
            /*Bukkit.getLogger().info("Passes Check 1");
            Bukkit.getLogger().info("Chunks without mult Chunk x: " + chunkX + " Chunk z: " + chunkZ);
            Bukkit.getLogger().info("Chunks with mult Chunk x: " + chunkX * 16 + " Chunk z: " + chunkZ * 16);
            Bukkit.getLogger().info("Chunk X: " + chunk.getBlockX() + " Chunk Z: " + chunk.getBlockZ());
            Bukkit.getLogger().info("In chunk x" + (chunk.getBlockX() == chunkX || chunk.getBlockX() <= chunkX*16));
            Bukkit.getLogger().info("In chunk z" + (chunk.getBlockZ() == chunkZ || chunk.getBlockZ() <= chunkZ*16));*/
            if(chunk.getBlockX() == chunkX * 16 || chunk.getBlockX() * 16 <= chunkX+16) //See if the chunk that we are looking at is in the set
                //Bukkit.getLogger().info("Passes Check 2");
                if(chunk.getBlockZ() == chunkZ * 16 || chunk.getBlockZ() * 16 <= chunkZ+16){
                    //Bukkit.getLogger().info("Is in chunk!");
            boolean val = false;
                    //Will probably break here
                    for (BlockProperty block : core.chunkBlocks.get(chunk)) {
                        data.setBlock(block.blockLocation.getBlockX(),
                                block.blockLocation.getBlockY(),
                                block.blockLocation.getBlockZ(),
                                block.blockType);
                        val = true;
                    }
            }
            //if(val)
                //core.chunkBlocks.remove(chunk);
        }
    }

}
