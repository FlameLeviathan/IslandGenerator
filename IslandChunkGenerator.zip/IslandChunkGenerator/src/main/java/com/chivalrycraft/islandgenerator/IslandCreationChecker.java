package com.chivalrycraft.islandgenerator;

public class IslandCreationChecker {
    //This class will handle the checking for whether an island should be created or not
    //searches nearby chunks for islands and if there are no islands within 2-4 (set amount) of chunks, create an island
    //then register that island as being in those chunks in the database
    //Onchunkload
}
